backGap = 12
foreGap = 12
colorMode = 1
backFigure = 0  -- 0=line/ 1=circle/ 2=circle2
foreFigure = 0

rotateAngle = 2
xShift = 2
yShift = 2

-- Use this function to perform your initial setup
function setup()
    iparameter("backGap",5,15)
    iparameter("foreGap",5,15)   
    iparameter("backFigure",0,2)
    iparameter("foreFigure",0,2)
    iparameter("colorMode",0,1)
    touches = {}
end

function touched(touch)
    --getting multi touches
    if touch.state == ENDED then
        touches[touch.id] = nil
    else
        touches[touch.id] = touch
    end

    --position shifting
    if touch.state == MOVING then --and xInit <= WIDTH and xInit >= 0 then
        xShift = xShift+touch.deltaX
    end
    if touch.state == MOVING then --and yInit <= HEIGHT and yInit >= 0 then
        yShift = yShift+touch.deltaY
    end
end

-- This function gets called once every frame
function draw()
    smooth()
    noFill()
    ellipseMode(RADIUS)
    lineCapMode(SQUARE)
   
    if colorMode == 1 then
        background(255, 255, 255, 255)
        stroke(76, 83, 88, 255)
    else
        background(83, 78, 91, 255)
        stroke(255, 255, 255, 255)
    end
   
    translate(WIDTH/2,HEIGHT/2)

    --draw background
    drawFigure(backFigure, backGap)
   
    --draw foreground
    translate(xShift, yShift)
    rotate(getRotation())
    drawFigure(foreFigure, foreGap)
   
end

function drawFigure(figure, gap)
    if figure == 0 then
        strokeWidth(3)
        drawLines(gap)
    elseif figure == 1 then
        strokeWidth(1)
        drawCircles1(gap)
    else
        strokeWidth(1)
        drawCircles2(gap)
    end
end

--draw lines
function drawLines(gap)
    for i = -WIDTH/gap/2, WIDTH/gap/2 do
        line(gap*i, -HEIGHT/2, gap*i, HEIGHT/2)
    end
end

--draw circle
function drawCircles1(gap)
    for i = 1, WIDTH/gap do
        ellipse(-WIDTH/2,-HEIGHT/2, gap*i-2, gap*i)
        --ellipse(startPos+WIDTH/2, endPos, gap*i, gap*i)
    end
end

--draw circle2
function drawCircles2(gap)
    for i = 1, WIDTH/gap/2 do
        ellipse(0, 0, gap*i, gap*i)   
    end
end

--calculate rotate angle
function getRotation()
    id1 = nil
    id2 = nil
    i = 0
    for k, touch in pairs(touches) do
        if i == 0 then
            id1 = k
        elseif i == 1 then
            id2 = k
        end
        i = i + 1
    end
    if i > 1 then
        v1 = vec2(touches[id2].prevX-touches[id1].prevX,
                touches[id2].prevY-touches[id1].prevY)
        v2 = vec2(touches[id2].x-touches[id1].x,
                touches[id2].y-touches[id1].y)
        rotateAngle = rotateAngle + math.deg(v1:angleBetween(v2))
        --print(rotateAngle)
    end
    return rotateAngle
end
