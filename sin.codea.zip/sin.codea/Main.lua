-- sin

-- Use this function to perform your initial setup
function setup()
    iparameter("width1",2,30)
    iparameter("height1",10,120)
    iparameter("width2",2,30)
    iparameter("height2",10,120)
end

-- This function gets called once every frame
function draw()
    -- This sets a dark background color 
    background(255, 255, 255, 255)

    -- This sets the line thickness
    strokeWidth(1)


    
    stroke(0, 0, 0, 255)
    lasty = 0
    for x = 0, WIDTH do
        y = math.sin(x/width1)*height1 + HEIGHT/2
        line(x, lasty, x+1, y)
        lasty = y
    end


    strokeWidth(2)
    lasty = 0
    for x = 0, WIDTH do
        y = math.sin(x/width2)*height2 + HEIGHT/2
        line(x, lasty, x+1, y)
        lasty = y
    end
    
end

