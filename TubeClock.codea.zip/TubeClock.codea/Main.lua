-- TubeClock
_num = 10
_angnoise, _radiusnoise, _widnoise, _heinoise = 0,0,0,0
_angle = -math.pi/2
_radius = 100
_strokeCol = 254

-- Use this function to perform your initial setup
function setup()
    smooth()
    backingMode( RETAINED )
    clearBackground()
    
    _angnoise = myrandom(10)
    _radiusnoise = myrandom(10)
    _widnoise = myrandom(10)
    _heinoise = myrandom(10)

    centreX = WIDTH/2
    centreY = HEIGHT/2
end

function draw()
    strokeWidth(0.5)

    -- Do your drawing here
    _radiusnoise = _radiusnoise + 0.005;
    _radius = (noise(_radiusnoise) * 250) +5;
    
    _angnoise = _angnoise + 0.005
    _angle = _angle + (mynoise(_angnoise) * 6) - 3
    if _angle > 360 then
        _angle = _angle - 360
    elseif _angle < 0 then
        _angle = _angle + 360
    end

    --tube size
    _widnoise = _widnoise + 0.05
    _heinoise = _heinoise + 0.05
    wid = (mynoise(_widnoise) * 25) +20
    hei = (mynoise(_heinoise) * 25) +20

    rad = math.rad(_angle)
    x1 = centreX + (_radius * math.cos(rad))
    y1 = centreY + (_radius * math.sin(rad))

    noFill();
    if _strokeCol > 0 then
        _strokeCol = _strokeCol - 2
    end
    stroke(_strokeCol, 50);
    ellipse(x1, y1, wid, hei);
end


function touched(touch)
    if CurrentTouch.state == BEGAN then
        clearBackground()
    end
end

function clearBackground()
    background(255)
end

function mynoise(x)
    return (noise(x)+1)/2
end

function myrandom(x)
    return math.random()*x
end
