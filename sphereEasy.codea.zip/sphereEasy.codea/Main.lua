frameCount = 0.0
radius = 100.0

function setup()
    --background(255)
    --backingMode(RETAINED)
    smooth()
    stroke(0,20)
    strokeWidth(0.5)
end

function draw()
    background(255)
    perspective(20)
    camera(WIDTH/2,800,800, WIDTH/2,HEIGHT/2,0)   

    translate(WIDTH/2, HEIGHT/2, 0)
    rotate(0, frameCount * 0.03, frameCount * 0.04)
    frameCount = frameCount + 1.0

    s = 0.0
    t = 0.0
    lastx = 0.0
    lasty = 0.0
    lastz = 0.0
    
    while t < 500 do
        s = s + 2.0
        radianS = s/180.0 * math.pi
        t = t + 0.5
        radianT = t/180.0 * math.pi
        --print(s, t)
        
        thisx = radius * math.cos(radianS) * math.sin(radianT)
        thisy = radius * math.sin(radianS) * math.sin(radianT)
        thisz = radius * math.cos(radianT)
        
        if lastx ~= 0.0 then
            line(thisx, thisy, thisz, lastx, lasty, lastz)
        end
        lastx = thisx
        lasty = thisy
        lastz = thisz
    end
end
