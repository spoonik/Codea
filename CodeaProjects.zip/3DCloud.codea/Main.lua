--3D Box including Clouds
----3D Box is rotated holding clouds inside

-- all the unique vertices that make up a cube
local vertices = {
      vec3(-2.5, -2.5,  2.5), -- Left  bottom front
      vec3( 2.5, -2.5,  2.5), -- Right bottom front
      vec3( 2.5,  2.5,  2.5), -- Right top    front
      vec3(-2.5,  2.5,  2.5), -- Left  top    front
      vec3(-2.5, -2.5, -2.5), -- Left  bottom back
      vec3( 2.5, -2.5, -2.5), -- Right bottom back
      vec3( 2.5,  2.5, -2.5), -- Right top    back
      vec3(-2.5,  2.5, -2.5), -- Left  top    back
    }
spacing = 5

sideLength = 200

xstart = math.random() * 10
ystart = math.random() * 10
zstart = math.random() * 10

-- Use this function to perform your initial setup
function setup()
    parameter.boolean("selectCube", false)
    
    smooth()
    noStroke()
    
    -- now construct a cube out of the vertices above
    local cubeverts = {
      -- Front
      vertices[1], vertices[2], vertices[3],
      vertices[1], vertices[3], vertices[4],
      -- Right
      vertices[2], vertices[6], vertices[7],
      vertices[2], vertices[7], vertices[3],
      -- Back
      vertices[6], vertices[5], vertices[8],
      vertices[6], vertices[8], vertices[7],
      -- Left
      vertices[5], vertices[1], vertices[4],
      vertices[5], vertices[4], vertices[8],
      -- Top
      vertices[4], vertices[3], vertices[7],
      vertices[4], vertices[7], vertices[8],
      -- Bottom
      vertices[5], vertices[6], vertices[2],
      vertices[5], vertices[2], vertices[1],
    }

    --create mesh
    ms = mesh()
    ms.vertices = cubeverts

    frameCount = 0
end

-- This function gets called once every frame
function draw()
    background(0)

    xstart = xstart + 0.01
    ystart = ystart + 0.01
    zstart = zstart + 0.01
    
    xnoise = xstart
    ynoise = ystart
    znoise = zstart
    
    --swith drawing 3D cloud box OR weave ----------
    if selectCube then
        --draw 3D cloud box
        perspective(25)
        camera(-10,-800,700, 100,100,0)   
        
        translate(150,20,-150)
        rotate(frameCount,0,0,1)
        frameCount = frameCount + 3
        if frameCount > 360 then
            frameCount = frameCount - 360
        end

        drawCloudsBox()
    else
        --draw 2D cloud weave
        perspective(15)
        camera(100,1000,350, 100,100,-100)
        drawCloudsWeave()
    end
end


-- This function gets called once every frame
function drawCloudsBox()
    for z=0,sideLength,spacing do
        znoise = znoise + 0.1
        ynoise = ystart
        
        for y=0,sideLength,spacing do
            ynoise = ynoise + 0.1
            xnoise = xstart
            
            for x=0,sideLength,spacing do
                xnoise = xnoise + 0.1
                noiseParam = (noise(xnoise,ynoise,znoise)+1.0)/2
                drawPoint1(x, y, z, noiseParam)
            end
        end
    end
end

-- This function gets called once every frame
function drawCloudsWeave()
    xstart = xstart + 0.01
    ystart = ystart + 0.01
    
    xnoise = xstart
    ynoise = ystart
        
    for y=0,sideLength,spacing do
        ynoise = ynoise + 0.1
        xnoise = xstart
            
        for x=0,sideLength,spacing do
            xnoise = xnoise + 0.1
            noiseParam = (noise(xnoise,ynoise,znoise)+1.0)/2
            drawPoint2(x, y, noiseParam)
        end
    end
end

--draw 3D cloud
function drawPoint1(x, y, z, noiseParam)
    pushMatrix()

    translate(x,y,z)
    grey = noiseParam * 255
    ms:setColors(grey,grey,grey,15)
    ms:draw()
    
    popMatrix()
end

--draw 3D cloud
function drawPoint2(x, y, noiseParam)
    pushMatrix()

    translate(x,250-y,-y)
    sphereSize = noiseParam * 35
    grey = 150 + noiseParam * 120
    ms:setColors(grey,grey,grey,grey)
    scale(sphereSize/12)
    ms:draw()
    
    popMatrix()
end

-- Creates an image of an ellipse and rect
function createCloudsImage()
    myImage = image(area,area)
    
    setContext( myImage )
    drawClouds()
    setContext()
    
    return myImage
end


