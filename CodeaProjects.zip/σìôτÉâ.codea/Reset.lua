--control the Reset button behavior
--when user pushes Reset 5times sequencially, the saved scores are discarded.
--if other input is inserted between those push, resetCount is reset.
resetCount = 0
function ResetData()
    resetCount = resetCount + 1
    if resetCount > 4 then
        clearLocalData()
        resetCount = 0
        loadScores(teamcount)
        return true
    end
    return false
end
function ResetResetPushCount()
    resetCount = 0
end