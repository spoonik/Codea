-- NoiseGrid
xstart = math.random() * 10
xnoise = xstart
ynoise = math.random() * 10
xstartNoise = math.random() * 20
ystartNoise = math.random() * 20
xstart = math.random() * 10
ystart = math.random() * 10

--limited area is drawn
hstart = WIDTH/2 - 100
hend = WIDTH/2 + 100
vstart = HEIGHT/2 - 100
vend = HEIGHT/2 + 100

step = 5

-- Use this function to perform your initial setup
function setup()
    parameter.integer("noiseType", 1, 3, 1, setParams)
    smooth()
    strokeWidth(1)
end

function setParams()
    if noiseType == 1 then
        step = 1
        drawFunc = drawPoint1
    else
        step = 5
        if noiseType == 2 then
            drawFunc = drawPoint2
        else
            drawFunc = drawPoint3
        end
    end
end

-- This function gets called once every frame
function draw()
    background(255)
    
    xstartNoise = xstartNoise + 0.01
    ystartNoise = ystartNoise + 0.01
    xstart = xstart + ((noise(xstartNoise)+1)/4) - 0.25
    ystart = ystart + ((noise(ystartNoise)+1)/4) - 0.25
    
    xnoise = xstart
    ynoise = ystart
    
    for y = vstart,vend,step do
        ynoise = ynoise + 0.1
        xnoise = xstart

        for x = hstart,hend,step do
            xnoise = xnoise + 0.1
            noiseParam = (noise(xnoise, ynoise)+1.0)/2
            drawFunc(x, y, noiseParam)
        end
    end
end

--draw 2D cloud
function drawPoint1(x, y, noiseParam)
    stroke(0, noiseParam*255)
    line(x,y,x+1,y+1)
end

--draw variable rect
function drawPoint2(x, y, noiseParam)
    len = 10 * noiseParam
    rect(x, y, len, len)
end

--draw grass-like pattern
function drawPoint3(x, y, noiseParam)
    pushMatrix()
    translate(x,y)
    rotate(noiseParam * 360)
    stroke(0, 150)
    line(0, 0, 20, 0)
    popMatrix()
end
