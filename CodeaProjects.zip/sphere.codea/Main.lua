function setup()
    --
 --   displayMode(FULLSCREEN)
    backingMode(RETAINED)
    Xpos = 0
    Ypos = 0
    Zpos = 0
    z = 0
    StepsV = 36
    StepsH = StepsV
    degs = 360/StepsV
    midX = WIDTH/2
    midY = HEIGHT/2
    mouseX = 0
    mouseY = 0
    perspective(90)
 --   Polar:init(20)
t = 0
    noSmooth()
end

-- This function gets called once every frame
function draw()
   -- perspective(none)
--ortho()
    perspective(90)
  
--zLevel(-20)
 --background(0, 0, 0, 16)   
   -- translate(midX, midY)
    translate(0,0,-220)
    
   

   fill(0, 0, 0, 56)
--zLevel(20)
pushMatrix()
zLevel(-1)
translate(0,0,-1220)
  rect(-WIDTH*10,-HEIGHT*10,WIDTH*45,HEIGHT*45)    
fill(0, 255, 30, 255)
popMatrix()
 
    camera(mouseX, mouseY, 220.400, -- eyeX, eyeY, eyeZ
 0.0, 0.0, 0.0, -- centerX, centerY, centerZ
 0.0, 1.0, 0.0); -- upX, upY, up 
    
    -- This sets a dark background color 
--    background(0, 0, 0, 255)
    stroke(23, 255, 0, 255)

    -- This sets the line thickness 
 --   strokeWidth(5)
    -- Do your drawing here
               rotate(t/3,0,1,1)
    pushMatrix()
    for i = 1, StepsV, 1 do
        rotate(degs,0,1,0)
        for a = 90, 270, degs do
            pushMatrix()        
            lineLength = WIDTH/3
            Xpos1 = Xpos+(math.cos(math.rad(a))*lineLength)
            Ypos1 = Ypos+(math.sin(math.rad(a))*lineLength)
            Zpos1 = Zpos+(math.sin(math.rad(z-90)*lineLength))
       --     stroke(0, 251, 0, 255)
            --rotate(t)
           -- pushMatrix()
           -- resetMatrix()
            pushMatrix()
            translate(Xpos1, Ypos1)
            rotate(math.random(0,360),1,1,1)
           ellipse(0,0,5,5)
            popMatrix()
    --    popMatrix()
        --    point(Xpos1, Ypos1) 
            popMatrix()  
        end
    end
    popMatrix()
    t = t + 1
end

function touched()
    mouseX = mouseX + CurrentTouch.deltaX
    mouseY = mouseY + CurrentTouch.deltaY
end
