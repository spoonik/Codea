-- WaveClock
_angnoise = 0.0
_radiusnoise = 0.0
_xnoise = 0.0
_ynoise = 0.0
_angle = math.pi/2
_radius = 0.0
_strokeCol = 254
_strokeChange = -1

function setup()
    backingMode( RETAINED )
    background(255)
    smooth()
    noFill()
    strokeWidth(1)
    
    _angnoise = math.random()*10
    _radiusnoise = math.random()*10
    _xnoise = math.random()*10
    _ynoise = math.random()*10
end

function draw()
    
    _radiusnoise = _radiusnoise + 0.005
    _radius = ((noise(_radiusnoise)+1)/2 * WIDTH*5/4) + 1
    
    _angnoise = _angnoise + 0.005
    _angle = _angle + ((noise(_angnoise)+1)/2 * 6) - 3
    if _angle > 360 then
        _angle = _angle - 360
    elseif _angle < 0 then
        _angle = _angle + 360
    end

    _xnoise = _xnoise + 0.01
    _ynoise = _ynoise + 0.01
    centerx = WIDTH/2 + ((noise(_xnoise)+1)/2 * 100) - 50
    centery = HEIGHT/2 + ((noise(_ynoise)+1)/2 * 100) - 50
    
    rad = _angle/180 * math.pi
    x1 = centerx + (_radius * math.cos(rad))
    y1 = centery + (_radius * math.sin(rad))
    opprad = rad + math.pi
    x2 = centerx + (_radius * math.cos(opprad))
    y2 = centery + (_radius * math.sin(opprad))
    
    _strokeCol = _strokeCol + _strokeChange
    if _strokeCol > 254 then
        _strokeChange = -1
    elseif _strokeCol <0 then
        _strokeChange = 1
    end
    stroke(_strokeCol, 60)
    line(x1, y1, x2, y2)
end
