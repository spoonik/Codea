-- Use this function to perform your initial setup
function setup()
    pattern = {}
    teama, teamb = 0, 0
    -- fill the patterns with empties to initialize
    for i = 1, teamcount do
        pattern[i] = {}
        for j = 1, teamcount do
            pattern[i][j] = false
        end
    end

    --if 3rd game should be counted (depending tournament's condition), 3rd game's max point is 15
    if count3rdGame then
        set3max=15
    else
        --if not, 3rd game's max point is 5
        set3max=5
    end

    parameter.integer("set1a",0,15,0,function(x) updateScore(teama,teamb,1,teama,set1a) end)
    parameter.integer("set1b",0,15,0,function(x) updateScore(teama,teamb,1,teamb,set1b) end)
    parameter.integer("set2a",0,15,0,function(x) updateScore(teama,teamb,2,teama,set2a) end)
    parameter.integer("set2b",0,15,0,function(x) updateScore(teama,teamb,2,teamb,set2b) end)
    parameter.integer("set3a",0,set3max,0,function(x) updateScore(teama,teamb,3,teama,set3a) end)
    parameter.integer("set3b",0,set3max,0,function(x) updateScore(teama,teamb,3,teamb,set3b) end)
    parameter.action("Total",function() sumUp() end)
    parameter.action("5 tap to clear",function() ResetData() end)
    --recover saved data
    loadScores(teamcount)
end

-- This function gets called once every frame
function draw()
    background(0,0,0,255)
    local w = WIDTH / (teamcount+1)
    local h = HEIGHT / (teamcount+1)
    -- text format
    font("HelveticaNeue-CondensedBlack")
    textWrapWidth(w)
    textAlign(CENTER)
    for i=1,teamcount+1 do
        for j=1,teamcount+1 do
            x, y = (j-1)*w, (teamcount-i+1)*h
            noStroke();
            if i==1 or j==1 then
                fill(106, 173, 227, 255)
            elseif pattern[i-1][j-1] then
                fill(230, 197, 75, 255)
            elseif i==j then
                fill(127, 127, 141, 255)
            else
                if i<j then
                    fill(216, 216, 216, 255)
                else
                    fill(176, 176, 176, 255)
                end
            end
            rect(x, y, w, h)
            if i~=1 and j~=1 and j~=i then
                winInfo = getWinSetCnt(i-1,j-1,3)
                if winInfo[1]>=2 then
                    fill(56, 56, 252, 255)
                elseif winInfo[1]<winInfo[2]/2 then
                    fill(252, 31, 48, 255)
                else
                    fill(29, 188, 57, 255)
                end
                fontSize(40)
                text(winInfo[1], x+w/5, y+h/2)
                fontSize(18)
                text(getSetScoreStr(i-1,j-1,"\n"), x+w*2/3, y+h/2)
            elseif i==1 and j~=1 then
                fill(255, 255, 255, 255)
                fontSize(22)
                text(getTeamName(j-1), x+w/2, y+h/2)
            elseif j==1 and i~=1 then
                fill(255, 255, 255, 255)
                fontSize(22)
                text(getTeamName(i-1), x+w/2, y+h/2)
            end
        end
    end
    --Sum display
    displaySumUp()
    --tap selection handling
    if CurrentTouch.state == BEGAN and not touchHandled then
        touchHandled = true
        checkFingerDown(CurrentTouch.x, CurrentTouch.y)
    elseif CurrentTouch.state == ENDED then
        touchHandled = false
    end
end

function checkFingerDown(x, y)
    teama = 0
    teamb = 0
    -- clear flags
    for i=0,teamcount-1,1 do
        for j=0,teamcount-1,1 do
            pattern[i+1][j+1] = false
        end
    end
    -- convert the finger to the grid location
    x = math.floor(x/WIDTH*(teamcount+1))
    y = math.floor((HEIGHT-y)/HEIGHT*(teamcount+1))
    if x<=0 or y<=0 then return end
    print(x,y)
    if pattern[y][x] then
        pattern[y][x] = false
    elseif x~=y then
        pattern[y][x] = true
        teama = y
        teamb = x
    end
    --re-display the selected cell's scores on param area
    refreshParams()
end

function refreshParams()
    print("a"..teama.."-b"..teamb)
    --get and insert scores to param sliders
    set1a = getScore(teama,teamb,1,teama)
    set1b = getScore(teama,teamb,1,teamb)
    set2a = getScore(teama,teamb,2,teama)
    set2b = getScore(teama,teamb,2,teamb)
    set3a = getScore(teama,teamb,3,teama)
    set3b = getScore(teama,teamb,3,teamb)
    --reset Reset function button
    ResetResetPushCount()
    --clear sum calculation display
    HideSumUp()
end
