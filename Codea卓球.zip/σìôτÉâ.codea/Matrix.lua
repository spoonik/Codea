--member variables
visibleSumUp = false
sumMatrix = {}

--switch function when SumButton is pushed
function sumUp()
    --calculate sum up
    createSumMatrix()
    --create CSV data
    csvStr = createCSVDataString()
    --export CSV data out to the defined data file
    saveProjectTab("XportedCSV", csvStr)
    --switch display flag on
    visibleSumUp = true
end

--calculate win-lose matrix : contains;
-- team number
-- win match count
-- win set count
-- win-lose order
-- win point
function createSumMatrix()
    for i=1,teamcount do
        sumMatrix[i] = {team=i,
                winCnt=getTotalWinMatchCount(i),
                winSetCnt=getRealTotalWinSetCount(i),
                order=0,
                point=0}
    end
    --calculate team win order
    table.sort(sumMatrix, compfuncWinOrder)
    --record calculated order
    for i=1,teamcount do
        sumMatrix[i].order = i
    end
    --recover team id order
    table.sort(sumMatrix, compfuncTeamOrder)
    --calculate team point
    for i=1,teamcount do
        sumMatrix[i].point = sumMatrix[i].winCnt
                +sumMatrix[i].winSetCnt
                +(teamcount-sumMatrix[i].order+1)
    end
end

--calculate winner order (1 is top winner)
-- this is sort sub function
function compfuncWinOrder(a,b)
    if a.winCnt > b.winCnt then
        return true
    elseif a.winCnt == b.winCnt then
        if a.winSetCnt > b.winSetCnt then
            return true
        elseif a.winSetCnt == b.winSetCnt then
            tmp = getWinSetCnt(a.team,b.team,3)
            if tmp[1] > 2 then
                return true
            end
        end
    end
    return false
end

--recover team number order in matrix
-- this is used after win order is calculated and recorded in the matrix
-- this is sort sub function
function compfuncTeamOrder(a,b)
    if a.team < b.team then
        return true
    end
    return false
end

--display sumMatrix info onto screen
function displaySumUp()
    local w = WIDTH / (teamcount+1)
    local h = HEIGHT / (teamcount+1)
    textWrapWidth(WIDTH)
    if visibleSumUp then
        for i=1,teamcount+1 do
            --draw transparent mesh on score table as background
            x, y = w, (teamcount-i+1)*h
            fill(0, 0, 0, 125)
            rect(x, y, WIDTH-w, h)
            if i>1 then
            --draw SumUp info on the background
            fill(255, 255, 255, 255)
            fontSize(40)
            text(sumMatrix[i-1].winCnt.."勝", x+w, y+h/2)
            fontSize(25)
            text(sumMatrix[i-1].winSetCnt.."セット", x+w*3, y+h/2)
            fontSize(40)
            if sumMatrix[i-1].order==1 then
                fill(255, 254, 0, 255)
            end
            text(sumMatrix[i-1].order.."位", x+w*5, y+h/2)
            fontSize(25)
            text(sumMatrix[i-1].point.."point", x+w*7, y+h/2)
            end
        end
    end
end
function HideSumUp()
    visibleSumUp = false
end

--calculate total win match count
function getTotalWinMatchCount(team)
    winMatch = 0
    for i=1,teamcount,1 do
        vicInfo=getWinSetCnt(team,i,3)
        if vicInfo[1] >= 2 then
            winMatch = winMatch + 1
        end
    end
    return winMatch
end

--calculate total win set count, excluding 3rd set
function getRealTotalWinSetCount(team)
    winSet = 0
    --set if 3rd game should be counted (depending tournament's condition)
    if count3rdGame then
        maxSet=3
    else
        maxSet=2
    end

    for i=1,teamcount,1 do
        vicInfo = getWinSetCnt(team,i,maxSet)
        winSet = winSet + vicInfo[1]
    end
    return winSet
end

--create CSV data string
function createCSVDataString()
    ret = ""
    --create whole string
    for i=1,teamcount do
        tmp = getTeamName(i)..","
        for j=1,teamcount do
            tmp = tmp..getSetScoreStr(i,j,",")..","
        end
        tmp = tmp..sumMatrix[i].winCnt..","
        tmp = tmp..sumMatrix[i].winSetCnt..","
        tmp = tmp..sumMatrix[i].order..","
        tmp = tmp..sumMatrix[i].point
        ret = ret.."\n"..tmp
    end
    return ret
end
