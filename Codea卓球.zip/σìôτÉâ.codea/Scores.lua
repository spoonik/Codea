scores = {}

--**CAUTION**
--   getScore and updateScore need score normalized.
--   'normalized' means, 'scores' database should be always
--   accessed using 'smaller-larger' team order.
--   So these function swap teama and teamb param on demand.
--   This allows caller to pass teama/b as is on table view.

--retrieve each team's score from score database
--  whichteam: 1=left side team on the table view
--             2=top side team on the table view
function getScore(teama,teamb,set,whichteam)
    if teama==nil or teamb==nil then return nil end
    if teama==0 or teamb==0 then return 0 end
    if teama < teamb then
        return scores[getTeamId(teama)..getTeamId(teamb)..set..getTeamId(whichteam)]
    else
        return scores[getTeamId(teamb)..getTeamId(teama)..set..getTeamId(whichteam)]
    end
end

--reflect selected cell param to scoreDB
function updateScore(teama,teamb,set,whichteam,score)
    if teama==0 or teamb==0 or teamb==teama then return end

    if teama < teamb then
        scores[getTeamId(teama)..getTeamId(teamb)..set..getTeamId(whichteam)] = score
        saveLocalData(getTeamId(teama)..getTeamId(teamb)..set..getTeamId(whichteam), score)
    else
        scores[getTeamId(teamb)..getTeamId(teama)..set..getTeamId(whichteam)] = score
        saveLocalData(getTeamId(teamb)..getTeamId(teama)..set..getTeamId(whichteam), score)
    end
end

--count win set count of a pair of 2teams, considering set count (2 or 3)
-- return value is array;
--   1: win set count
--   2: total set count
function getWinSetCnt(i,j,includeSet)
    reverse = i>j
    retval = 0
    totalSet = 0
    retInfo = {}
    if reverse then
        tmp=i
        i=j
        j=tmp
    end
    tmp1a = scores[getTeamId(i)..getTeamId(j).."1"..getTeamId(i)]
    tmp1b = scores[getTeamId(i)..getTeamId(j).."1"..getTeamId(j)]
    tmp2a = scores[getTeamId(i)..getTeamId(j).."2"..getTeamId(i)]
    tmp2b = scores[getTeamId(i)..getTeamId(j).."2"..getTeamId(j)]
    tmp3a = scores[getTeamId(i)..getTeamId(j).."3"..getTeamId(i)]
    tmp3b = scores[getTeamId(i)..getTeamId(j).."3"..getTeamId(j)]
    if tmp1a~=nil and tmp1b~=nil and includeSet>=1 then
        totalSet = totalSet + 1
        if reverse==false and tmp1a > tmp1b then
            retval = retval + 1
        elseif reverse and tmp1a<tmp1b then
            retval = retval + 1
        end
    end
    if tmp2a~=nil and tmp2b~=nil and includeSet>=2 then
        totalSet = totalSet + 1
        if reverse==false and tmp2a > tmp2b then
            retval = retval + 1
        elseif reverse and tmp2a<tmp2b then
            retval = retval + 1
        end
    end
    if tmp3a~=nil and tmp3b~=nil and includeSet>=3 then
        totalSet = totalSet + 1
        if reverse==false and tmp3a > tmp3b then
            retval = retval + 1
        elseif reverse and tmp3a<tmp3b then
            retval = retval + 1
        end
    end
    retInfo[1] = retval
    retInfo[2] = totalSet
    return retInfo
end

--create dispaly score cell string, considering 'separator'
-- for display or CSV only
function getSetScoreStr(i,j,sep)
    retval = ""
    reverse = i>j
    --special case
    if i==j then
        return sep..sep
    end
    if reverse then
        tmp=i
        i=j
        j=tmp
    end
    tmp1a = scores[getTeamId(i)..getTeamId(j).."1"..getTeamId(i)]
    tmp1b = scores[getTeamId(i)..getTeamId(j).."1"..getTeamId(j)]
    tmp2a = scores[getTeamId(i)..getTeamId(j).."2"..getTeamId(i)]
    tmp2b = scores[getTeamId(i)..getTeamId(j).."2"..getTeamId(j)]
    tmp3a = scores[getTeamId(i)..getTeamId(j).."3"..getTeamId(i)]
    tmp3b = scores[getTeamId(i)..getTeamId(j).."3"..getTeamId(j)]
    if tmp1a ~= nil and tmp1b ~= nil then
        if reverse==false then
            retval = tmp1a.."-"..tmp1b
        else
            retval = tmp1b.."-"..tmp1a
        end
    end
    if tmp2a ~= nil and tmp2b ~= nil then
        if reverse==false then
            retval = retval..sep..tmp2a.."-"..tmp2b
        else
            retval = retval..sep..tmp2b.."-"..tmp2a
        end
    else
        retval = retval..sep
    end
    if tmp3a ~= nil and tmp3b ~= nil then
        if tmp3a~=0 or tmp3b~=0 then
            if reverse==false then
                retval = retval..sep..tmp3a.."-"..tmp3b
            else
                retval = retval..sep..tmp3b.."-"..tmp3a
            end
        end
    else
        retval = retval..sep
    end
    return retval
end

--convert 1,2,3... team number to A,B,C...
-- because of primitive storage system, using Dictionary index
function getTeamId(i)
    teamOrder = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P"}
    return teamOrder[i]
end

function getTeamName(i)
    return teamName[i]
end

function loadScores(max)
    for i=1,max,1 do
        for j=i+1,max,1 do
            for set=1,3 do
                loc = getTeamId(i)..getTeamId(j)..set..getTeamId(i)
                scores[loc] = readLocalData(loc)
                loc = getTeamId(i)..getTeamId(j)..set..getTeamId(j)
                scores[loc] = readLocalData(loc)
            end
        end
    end
end
